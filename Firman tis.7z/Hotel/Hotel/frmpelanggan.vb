﻿Public Class frmpelanggan
    Private Sub frmpelanggan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Reload()
    End Sub

    Private Sub Reload()
        oPelanggan.getalldata(DataGridView2)
    End Sub
    Private Sub TampilPelanggan()
        txtid_pelangan.Text = oPelanggan.id_pelanggan
        txtnama_pelanggan.Text = opelanggan.nama_pelanggan
        txtalamat.Text = opelanggan.alamat
        txtno_tlp.Text = opelanggan.no_tlp
    End Sub

    Private Sub SimpanDatapelanggan()
        oPelanggan.id_pelanggan = txtid_pelangan.Text
        opelanggan.nama_pelanggan = txtnama_pelanggan.text
        opelanggan.alamat = txtalamat.text
        opelanggan.no_tlp = txtno_tlp.text
        opelanggan.Simpan()
        Reload()
        If (opelanggan.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (opelanggan.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub

    Private Sub ClearEntry()
        txtid_pelangan.Clear()
        txtnama_pelanggan.Clear()
        txtalamat.Clear()
        txtno_tlp.Clear()
        txtid_pelangan.Focus()
    End Sub

    Private Sub Hapus()
        If (pelanggan_baru = False And txtid_pelangan.Text <> "") Then
            oPelanggan.Hapus(txtid_pelangan.Text)
            ClearEntry()
            Reload()
        End If
    End Sub
    Private Sub txtid_pelanggan_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If (e.KeyCode = Keys.Enter) Then
            oPelanggan.Caripelanggan(txtid_pelangan.Text)
            If (pelanggan_baru = False) Then
                TampilPelanggan()
            Else
                MessageBox.Show("Data tidak ditemukan")
            End If
        End If
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsimpan.Click
        If (txtid_pelangan.Text <> "" And txtnama_pelanggan.Text <> "") Then
            SimpanDatapelanggan()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("no_kamar dan jenis_kamar tidak boleh kosong!")
        End If
    End Sub
    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        ClearEntry()
    End Sub

    Private Sub txtid_pelangan_TextChanged(sender As Object, e As EventArgs) Handles txtid_pelangan.TextChanged

    End Sub
End Class
