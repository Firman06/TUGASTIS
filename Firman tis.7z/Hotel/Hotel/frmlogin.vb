﻿Public Class frmlogin
    
    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        login_valid = oUser.Login(txtusername.Text, txtpassword.Text)
        If (login_valid = True) Then
            frmenu.Show()
            Me.Hide()
        Else
            MessageBox.Show("Login Not Valid")
        End If
    End Sub
End Class
