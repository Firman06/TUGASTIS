﻿Public Class Pelanggan
    Dim strsql As String
    Dim info As String
    Private _id_pelanggan As Integer
    Private _nama_pelanggan As String
    Private _alamat As String
    Private _no_tlp As String
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property id_pelanggan()
        Get
            Return _id_pelanggan
        End Get
        Set(ByVal value)
            _id_pelanggan = value
        End Set
    End Property
    Public Property nama_pelanggan()
        Get
            Return _nama_pelanggan
        End Get
        Set(ByVal value)
            _nama_pelanggan = value
        End Set
    End Property
    Public Property alamat()
        Get
            Return _alamat
        End Get
        Set(ByVal value)
            _alamat = value
        End Set
    End Property
    Public Property no_tlp()
        Get
            Return _no_tlp
        End Get
        Set(ByVal value)
            _no_tlp = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (pelanggan_baru = True) Then
            strsql = "Insert into pelanggan(id_pelanggan,nama_pelanggan,alamat,no_tlp) values ('" & id_pelanggan & "','" & nama_pelanggan & "','" & alamat & "','" & no_tlp & "')"
            info = "INSERT"
        Else
            strsql = "update pelanggan set id_pelanggan='" & id_pelanggan & "', nama_pelanggan='" & nama_pelanggan & "', alamat='" & alamat & "', no_tlp='" & no_tlp & "' where id_pelanggan='" & id_pelanggan & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Caripelanggan(ByVal sno_kamar As String)
        DBConnect()
        strsql = "SELECT * FROM pelanggan WHERE no_kamar='" & sno_kamar & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            pelanggan_baru = False
            DR.Read()
            id_pelanggan = Convert.ToString((DR("id_pelanggan")))
            nama_pelanggan = Convert.ToString((DR("nama_pelanggan")))
            alamat = Convert.ToString((DR("alamat")))
            no_tlp = Convert.ToString((DR("no_tlp")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            pelanggan_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sno_kamar As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM pelanggan WHERE no_kamar='" & sno_kamar & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM pelanggan"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class
