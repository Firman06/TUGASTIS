﻿Public Class Kamar
    Dim strsql As String
    Dim info As String
    Private _id_kamar As Integer
    Private _no_kamar As String
    Private _jenis_kamar As String
    Private _harga As Integer
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property no_kamar()
        Get
            Return _no_kamar
        End Get
        Set(ByVal value)
            _no_kamar = value
        End Set
    End Property
    Public Property jenis_kamar()
        Get
            Return _jenis_kamar
        End Get
        Set(ByVal value)
            _jenis_kamar = value
        End Set
    End Property
    Public Property harga()
        Get
            Return _harga
        End Get
        Set(ByVal value)
            _harga = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (kamar_baru = True) Then
            strsql = "Insert into kamar(no_kamar,jenis_kamar,harga) values ('" & no_kamar & "','" & jenis_kamar & "','" & harga & "')"
            info = "INSERT"
        Else
            strsql = "update kamar set no_kamar='" & no_kamar & "', jenis_kamar='" & jenis_kamar & "', harga='" & harga & "' where no_kamar='" & no_kamar & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Carikamar(ByVal sno_kamar As String)
        DBConnect()
        strsql = "SELECT * FROM kamar WHERE no_kamar='" & sno_kamar & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            kamar_baru = False
            DR.Read()
            no_kamar = Convert.ToString((DR("no_kamar")))
            jenis_kamar = Convert.ToString((DR("jenis_kamar")))
            harga = Convert.ToString((DR("harga")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            kamar_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sno_kamar As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM kamar WHERE no_kamar='" & sno_kamar & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM kamar"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class
