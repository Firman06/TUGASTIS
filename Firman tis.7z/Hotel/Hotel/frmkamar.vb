﻿Public Class frmkamar
    Private Sub frmkamar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Reload()
    End Sub

    Private Sub Reload()
        okamar.getAllData(DataGridView1)
    End Sub

    Private Sub TampilKamar()
        txtnokamar.Text = oKamar.no_kamar
        txtjeniskamar.Text = oKamar.jenis_kamar
        txtharga.Text = okamar.harga
    End Sub

    Private Sub SimpanDatakamar()
        oKamar.no_kamar = txtnokamar.Text
        oKamar.jenis_kamar = txtjeniskamar.Text
        okamar.harga = txtharga.text
        okamar.Simpan()
        Reload()
        If (okamar.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (okamar.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub

    Private Sub ClearEntry()
        txtnokamar.Clear()
        txtjeniskamar.Clear()
        txtharga.Clear()
        txtnokamar.Focus()
    End Sub

    Private Sub Hapus()
        If (kamar_baru = False And txtnokamar.Text <> "") Then
            oKamar.Hapus(txtnokamar.Text)
            ClearEntry()
            Reload()
        End If
    End Sub

    Private Sub txtno_kamar_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtnokamar.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            oKamar.Carikamar(txtnokamar.Text)
            If (kamar_baru = False) Then
                TampilKamar()
            Else
                MessageBox.Show("Data tidak ditemukan")
            End If
        End If
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsimpan.Click
        If (txtnokamar.Text <> "" And txtjeniskamar.Text <> "") Then
            SimpanDatakamar()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("no_kamar dan jenis_kamar tidak boleh kosong!")
        End If
    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        ClearEntry()
    End Sub
End Class